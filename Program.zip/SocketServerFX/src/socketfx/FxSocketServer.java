/*
 * Name:       Ke Swen Lee
 * Date:       26/11/2020
 * Student ID: 30010827
 * Reference:  https://blogs.oracle.com/jtc/update-to-javafx,-sockets-and-threading:-lessons-learned
 */
package socketfx;

import java.net.*;

public class FxSocketServer extends GenericSocket
        implements SocketListener {

    private SocketListener fxListener;
    private ServerSocket serverSocket;

    // Called when a message is received from the socket, read line.
    @Override
    public void onMessage(final String line) {
        javafx.application.Platform.runLater(new Runnable() {
            @Override
            public void run() {
                fxListener.onMessage(line);
            }
        });
    }

    // Called when the socket opens or closes
    @Override
    public void onClosedStatus(final boolean isClosed) {
        javafx.application.Platform.runLater(new Runnable() {
            @Override
            public void run() {
                fxListener.onClosedStatus(isClosed);
            }
        });
    }

    // Initialise server socket and issuing accept()
    @Override
    protected void initSocketConnection() throws SocketException {
        try {
            serverSocket = new ServerSocket(port);
            // Allows the socket to be bound even though a previous connection is in a timeout state.
            serverSocket.setReuseAddress(true);
            
            // Wait for connection from client
            if (debugFlagIsSet(Constants.instance().DEBUG_STATUS)) {
                System.out.println("Waiting for connection");
            }
            socketConnection = serverSocket.accept();
            if (debugFlagIsSet(Constants.instance().DEBUG_STATUS)) {
                System.out.println("Connection received from "
                        + socketConnection.getInetAddress().getHostName());
            }
        } catch (Exception e) {
            if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                e.printStackTrace();
            }
            throw new SocketException();
        }
    }

    // Close additional server sockets
    @Override
    protected void closeAdditionalSockets() {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public FxSocketServer(SocketListener fxListener,
            int port, int debugFlags) {
        super(port, debugFlags);
        this.fxListener = fxListener;
    }

    public FxSocketServer(SocketListener fxListener) {
        this(fxListener, Constants.instance().DEFAULT_PORT,
                Constants.instance().DEBUG_NONE);
    }

    public FxSocketServer(SocketListener fxListener, int port) {
        this(fxListener, port, Constants.instance().DEBUG_NONE);
    }
}
