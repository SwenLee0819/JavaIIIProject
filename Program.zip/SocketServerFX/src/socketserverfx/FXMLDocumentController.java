/*
 * Name:       Ke Swen Lee
 * Date:       26/11/2020
 * Student ID: 30010827
 * Reference:  https://blogs.oracle.com/jtc/update-to-javafx,-sockets-and-threading:-lessons-learned
 */
package socketserverfx;

import java.lang.invoke.MethodHandles;
import java.net.*;
import java.util.*;
import java.util.logging.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import socketfx.Constants;
import socketfx.FxSocketServer;
import socketfx.SocketListener;
import backstage.Login;

public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField textPort, textUser;
    @FXML
    private Button buttonStart;
    private final static Logger LOGGER
            = Logger.getLogger(MethodHandles.lookup().lookupClass().getName());
    private boolean isConnected;
    private FxSocketServer socket;

    public enum ConnectionDisplayState {
        DISCONNECTED, WAITING, CONNECTED
    }

    private void connect() {
        socket = new FxSocketServer(new FxSocketListener(),
                Integer.valueOf(textPort.getText()),
                Constants.instance().DEBUG_NONE);
        socket.connect();
    }

    private void displayState(ConnectionDisplayState state) {
        switch (state) {
            case DISCONNECTED:
                buttonStart.setDisable(false);
                textPort.setEditable(true);
                textUser.clear();
                textUser.setDisable(true);
                break;
            case WAITING:
                buttonStart.setDisable(true);
                textUser.setDisable(true);
                textPort.setEditable(false);
            case CONNECTED:
                buttonStart.setDisable(true);
                textPort.setEditable(false);
                textUser.setDisable(false);
                break;
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        textUser.setDisable(true);
        // Create users
        Login.createUsers();
    }

    class ShutDownThread extends Thread {

        @Override
        public void run() {
            if (socket != null) {
                if (socket.debugFlagIsSet(Constants.instance().DEBUG_STATUS)) {
                    LOGGER.info("ShutdownHook: Shutting down Server Socket");
                }
                socket.shutdown();
            }
        }
    }

    class FxSocketListener implements SocketListener {

        @Override
        public void onMessage(String line) {
            if (line != null && !line.equals("")) {
                if (line.startsWith("\\Login\\")) {
                    String[] credentials = line.split("\\\\");
                    String userID = credentials[2];
                    String password = credentials[3];

                    boolean result = Login.simulateLogin(userID, password);
                    String result2 = "\\Login\\" + Boolean.toString(result) + "\\" + userID;

                    if (result == true) {
                        textUser.setText(userID);
                    }
                    socket.sendMessage(result2);
                } else if (line.equals("\\Switch\\")) {
                    textUser.clear();
                } else if (line.startsWith("\\Create\\")) {
                    String[] credentials = line.split("\\\\");
                    String userID = credentials[2];
                    String password = credentials[3];
                    Login.simulateUserCreation(userID, password);
                }
            }
        }

        @Override
        public void onClosedStatus(boolean isClosed) {
            if (isClosed) {
                isConnected = false;
                displayState(ConnectionDisplayState.DISCONNECTED);
            } else {
                isConnected = true;
                displayState(ConnectionDisplayState.CONNECTED);
            }
        }
    }

    // Start server, wait for client connection
    @FXML
    private void handleStartButtonAction(ActionEvent event) {
        displayState(ConnectionDisplayState.WAITING);
        connect();
    }

}
