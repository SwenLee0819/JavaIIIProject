package backstage;

import java.util.*;

public class MockUserRepository {

    private List<User> users = new ArrayList<User>();

    // Add user
    public void addUser(User user) {
        users.add(user);
    }

    // Get user
    public User getUser(String userID) {
        try {
            boolean found = false;
            int index = 0;
            for (int i = 0; i < users.size(); i++) {
                if (userID.equals(users.get(i).getUserID())) {
                    index = i;
                    found = true;
                    break;
                } else {
                    found = false;
                }
            }
            if (found == true) {
                return users.get(index);
            } else {
                return null;
            }
        } catch (Exception e) {
            System.err.println("Exception: " + e);
            return null;
        }
    }

}
