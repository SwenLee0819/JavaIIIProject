package backstage;

public class PasswordManager {

    private HashComputer hashComp = new HashComputer();
    private String salt = null;

    // Generate hash password
    public String generatePasswordHash(String plainTextPassword, String salt) {
        try {
            salt = SaltGenerator.getSaltString();
            this.salt = salt;
            String finalString = plainTextPassword + salt;
            return hashComp.getPasswordHashAndSalt(finalString);
        } catch (Exception e) {
            return "Exception: " + e;
        }
    }

    // Set salt
    public String setSalt(String salt) {
        return this.salt;
    }

    // Chheck is password input matches
    public boolean isPasswordMatch(String password, String salt, String hash) {
        try {
            String finalString = password + salt;
            return hash.equals(hashComp.getPasswordHashAndSalt(finalString));
        } catch (Exception e) {
            System.err.println("Exception: " + e);
            return true;
        }
    }

}
