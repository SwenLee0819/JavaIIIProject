/*
 * Name:       Ke Swen Lee
 * Date:       26/11/2020
 * Student ID: 30010827
 */
package backstage;

import javafx.scene.control.Alert;
import java.util.*;

public class Login {

    private static final MockUserRepository USER_REPO = new MockUserRepository();
    private static final PasswordManager PWD_MANAGER = new PasswordManager();
    private static User user = new User();
    private static User newUser = new User();

    // Method to create users
    public static void createUsers() {
        try {
            // Create Administrator
            String saltAdmin = null;
            String pwHashAdmin = PWD_MANAGER.generatePasswordHash("P@ssw0rd", saltAdmin);
            saltAdmin = PWD_MANAGER.setSalt(saltAdmin);
            User admin = new User("Administrator", pwHashAdmin, saltAdmin);
            USER_REPO.addUser(admin);

            // Create Users
            String saltStu = null;
            String pwHashStu = PWD_MANAGER.generatePasswordHash("student", saltStu);
            saltStu = PWD_MANAGER.setSalt(saltStu);
            User student = new User("Student", pwHashStu, saltStu);
            USER_REPO.addUser(student);

            String saltUser1 = null;
            String pwHashUser1 = PWD_MANAGER.generatePasswordHash("jackson1128", saltUser1);
            saltUser1 = PWD_MANAGER.setSalt(saltUser1);
            User user1 = new User("Jackson", pwHashUser1, saltUser1);
            USER_REPO.addUser(user1);

            String saltUser2 = null;
            String pwHashUser2 = PWD_MANAGER.generatePasswordHash("karry0921", saltUser2);
            saltUser2 = PWD_MANAGER.setSalt(saltUser2);
            User user2 = new User("Karry", pwHashUser2, saltUser2);
            USER_REPO.addUser(user2);

            String saltUser3 = null;
            String pwHashUser3 = PWD_MANAGER.generatePasswordHash("roy1108", saltUser3);
            saltUser3 = PWD_MANAGER.setSalt(saltUser3);
            User user3 = new User("Roy", pwHashUser3, saltUser3);
            USER_REPO.addUser(user3);

            System.err.println();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Generating Users");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    // Method to simulate user creation
    public static void simulateUserCreation(String userID, String password) {
        try {
            String salt = null;
            String passwordHash = PWD_MANAGER.generatePasswordHash(password, salt);
            salt = PWD_MANAGER.setSalt(salt);
            newUser = new User(userID, passwordHash, salt);
            USER_REPO.addUser(newUser);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("User " + userID + " has been created");
            alert.setContentText("Time created: " + Calendar.getInstance().getTime());
            alert.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Creating User");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    // Method to simulate login
    public static boolean simulateLogin(String userID, String password) {
        try {
            user = USER_REPO.getUser(userID);

            if (user == null) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Error");
                alert.setHeaderText("Unexisting User");
                alert.setContentText("User " + userID + " does not exist");
                alert.show();
                return false;
            } else {
                boolean result = PWD_MANAGER.isPasswordMatch(password, user.getSalt(), user.getPasswordHash());
                if (result == true) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Welcome");
                    alert.setHeaderText("Welcome " + userID);
                    alert.setContentText("Time connected: " + Calendar.getInstance().getTime());
                    alert.show();
                    return true;
                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Error");
                    alert.setHeaderText("Incorrect Password");
                    alert.setContentText("Password for user " + userID + " is incorrect");
                    alert.show();
                    return false;
                }
            }

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Logging In");
            alert.setContentText(e.toString());
            alert.show();
            return false;
        }
    }

}
