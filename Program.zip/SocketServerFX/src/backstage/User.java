package backstage;

public class User {

    private String userID;
    private String passwordHash;
    private String salt;

    public User() {
    }

    public User(String userID, String passwordHash, String salt) {
        this.userID = userID;
        this.passwordHash = passwordHash;
        this.salt = salt;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

}
