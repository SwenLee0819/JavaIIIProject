package backstage;

import java.security.*;
import java.util.*;

public class SaltGenerator {

    private static Random random = null;
    private static final int KEY_LENGTH = 256;

    public SaltGenerator() {
        random = new SecureRandom();
    }

    // Method to generate salt
    public static String getSaltString() {
        try {
            StringBuilder sb = new StringBuilder(KEY_LENGTH);
            for (int i = 0; i < KEY_LENGTH; i++) {
                int c = random.nextInt(62);
                if (c <= 9) {
                    sb.append(String.valueOf(c));
                } else if (c < 36) {
                    sb.append((char) ('a' + c - 10));
                } else {
                    sb.append((char) ('A' + c - 36));
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return "Exception: " + e.toString();
        }
    }
}
