package backstage;

import com.opencsv.*;
import java.io.*;
import java.util.*;
import javafx.scene.control.Alert;
import javafx.scene.control.*;

public class Backstage {

    private static LinkedList<Integer> listID = new LinkedList<Integer>();
    private static LinkedList<String> listTitle = new LinkedList<String>();
    private static LinkedList<Double> listPrice = new LinkedList<Double>();
    private static LinkedList<String> listRating = new LinkedList<String>();
    private static LinkedList<Integer> listYear = new LinkedList<Integer>();
    private static LinkedList<String> listGenre = new LinkedList<String>();

    public static void readFile() {
        try {
            CSVReader reader = null;

            listID.clear();
            listTitle.clear();
            listPrice.clear();
            listRating.clear();
            listYear.clear();
            listGenre.clear();

            reader = new CSVReader(new FileReader("movies.csv"));

            List<String[]> movies = reader.readAll();

            // Adding data to array lists
            for (String[] movie : movies) {
                listID.addLast(Integer.parseInt(movie[0]));
                listTitle.addLast(movie[1]);
                listPrice.addLast(Double.parseDouble(movie[2]));
                listRating.addLast(movie[3]);
                listYear.addLast(Integer.parseInt(movie[4]));
                listGenre.addLast(movie[5]);
            }

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Reading File");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    public static void addToDisplay(LinkedList<String> listMovies) {
        try {
            listMovies.clear();
            for (int i = 0; i < listTitle.size(); i++) {
                String line = listTitle.get(i) + ", " + (listYear.get(i).toString());
                listMovies.addLast(line);
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Displaying List");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    public static void writeToFile(String title, Double price, String rating, Integer year, String genre) {
        try {
            CSVWriter writer = new CSVWriter(new FileWriter("movies.csv", true));
            Integer newID = listID.size() + 1;

            writer.writeNext(new String[]{newID.toString(), title, price.toString(), rating, year.toString(), genre});
            writer.close();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Writing to File");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    public static void sortTitle(LinkedList<String> sortedTitle) {
        LinkedList<Integer> tempID = new LinkedList<>();
        LinkedList<String> tempTitle = new LinkedList<>();
        LinkedList<Double> tempPrice = new LinkedList<>();
        LinkedList<String> tempRating = new LinkedList<>();
        LinkedList<Integer> tempYear = new LinkedList<>();
        LinkedList<String> tempGenre = new LinkedList<>();

        for (int i = 0; i < sortedTitle.size(); i++) {
            int index = listTitle.indexOf(sortedTitle.get(i));

            tempID.addLast(listID.get(index));
            tempTitle.addLast(listTitle.get(index));
            tempPrice.addLast(listPrice.get(index));
            tempRating.addLast(listRating.get(index));
            tempYear.addLast(listYear.get(index));
            tempGenre.addLast(listGenre.get(index));
        }

        listTitle = tempTitle;
        listID = tempID;
        listPrice = tempPrice;
        listRating = tempRating;
        listYear = tempYear;
        listGenre = tempGenre;
    }

    public static void sortID(LinkedList<Integer> sortedID) {
        LinkedList<Integer> tempID = new LinkedList<>();
        LinkedList<String> tempTitle = new LinkedList<>();
        LinkedList<Double> tempPrice = new LinkedList<>();
        LinkedList<String> tempRating = new LinkedList<>();
        LinkedList<Integer> tempYear = new LinkedList<>();
        LinkedList<String> tempGenre = new LinkedList<>();

        for (int i = 0; i < sortedID.size(); i++) {
            int index = listID.indexOf(sortedID.get(i));

            tempID.addLast(listID.get(index));
            tempTitle.addLast(listTitle.get(index));
            tempPrice.addLast(listPrice.get(index));
            tempRating.addLast(listRating.get(index));
            tempYear.addLast(listYear.get(index));
            tempGenre.addLast(listGenre.get(index));
        }

        listTitle = tempTitle;
        listID = tempID;
        listPrice = tempPrice;
        listRating = tempRating;
        listYear = tempYear;
        listGenre = tempGenre;
    }

    public static String find(String targetTitle) {
        int index = listTitle.indexOf(targetTitle);
        String nextID = listID.get(index).toString();
        String nextTitle = listTitle.get(index);
        String nextPrice = listPrice.get(index).toString();
        String nextRating = listRating.get(index);
        String nextYear = listYear.get(index).toString();
        String nextGenre = listGenre.get(index);
        return nextID + "," + nextTitle + "," + nextPrice + "," + nextRating + "," + nextYear + "," + nextGenre;
    }

    public static int binarySearchID(LinkedList<Integer> list, int target) {
        int index = 0;
        boolean found = false;

        int min = 0;
        int max = list.size() - 1;

        while (min <= max) {
            int mid = (min + max) / 2;
            if (target == list.get(mid)) {
                index = list.indexOf(target);
                found = true;
                break;
            } else if (target < list.get(mid)) {
                max = mid - 1;
                found = false;
            } else {
                min = mid + 1;
                found = false;
            }
        }

        if (found == true) {
            return index;
        } else {
            return -1;
        }
    }

    public static int binarySearchTitle(LinkedList<String> list, String target) {
        int index = 0;
        boolean found = false;

        int min = 0;
        int max = list.size() - 1;

        while (min <= max) {
            int mid = (min + max) / 2;
            if (target.compareTo(list.get(mid)) == 0) {
                index = list.indexOf(target);
                found = true;
                break;
            } else if (target.compareTo(list.get(mid)) < 0) {
                max = mid - 1;
                found = false;
            } else {
                min = mid + 1;
                found = false;
            }
        }

        if (found == true) {
            return index;
        } else {
            return -1;
        }
    }

    public static Integer getID(int index) {
        return listID.get(index);
    }

    public static String getTitle(int index) {
        return listTitle.get(index);
    }

    public static Double getPrice(int index) {
        return listPrice.get(index);
    }

    public static String getRating(int index) {
        return listRating.get(index);
    }

    public static Integer getYear(int index) {
        return listYear.get(index);
    }

    public static String getGenre(int index) {
        return listGenre.get(index);
    }

    public static LinkedList<String> getTitleList() {
        return listTitle;
    }

    public static LinkedList<Integer> getIDList() {
        return listID;
    }

}
