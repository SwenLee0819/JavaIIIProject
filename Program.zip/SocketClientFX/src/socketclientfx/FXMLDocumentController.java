package socketclientfx;

import java.lang.invoke.MethodHandles;
import java.net.*;
import java.util.*;
import java.util.logging.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.input.*;
import javafx.scene.control.*;
import socketfx.Constants;
import socketfx.FxSocketClient;
import socketfx.SocketListener;
import backstage.*;

public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField textPort, textUser, textUserID, textPassword, textSearch, textID,
            textTitleD, textPriceD, textRatingD, textYearD, textGenreD,
            textTitleA, textPriceA, textRatingA, textYearA, textGenreA;
    @FXML
    private Button buttonConnect, buttonSwitch, buttonClear, buttonCreate, buttonLogin, buttonClearSearch,
            buttonSearch, buttonReset, buttonPrev, buttonNext, buttonAdd, buttonSortID, buttonSortTitle;
    @FXML
    private ListView moviesList, searchList;
    @FXML
    private ComboBox comboFilters;
    @FXML
    private Label labelPort, labelUser, labelLogin, labelUserID, labelPassword, labelMovies, labelSearch,
            labelFilter, labelDetails, labelID, labelTitleD, labelPriceD, labelRatingD, labelYearD, labelGenreD,
            labelAdd, labelTitleA, labelPriceA, labelRatingA, labelYearA, labelGenreA;

    private final static Logger LOGGER
            = Logger.getLogger(MethodHandles.lookup().lookupClass().getName());

    private LinkedList<String> listMovies = new LinkedList<String>();
    private static final ObservableList<String> FILTERS = FXCollections.observableArrayList("Movie ID", "Title");
    private boolean connected;

    public enum ConnectionDisplayState {

        DISCONNECTED, ATTEMPTING, CONNECTED
    }

    private FxSocketClient socket;

    private synchronized void waitForDisconnect() {
        while (connected) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
    }

    private synchronized void notifyDisconnected() {
        connected = false;
        notifyAll();
    }

    private synchronized void setIsConnected(boolean connected) {
        this.connected = connected;
    }

    private synchronized boolean isConnected() {
        return (connected);
    }

    private void connect() {
        socket = new FxSocketClient(new FxSocketListener(),
                "localhost",
                Integer.valueOf(textPort.getText()),
                Constants.instance().DEBUG_NONE);
        socket.connect();
    }

    private void displayState(ConnectionDisplayState state) {
        switch (state) {
            case DISCONNECTED:
                unlockConnect();
                lockAll();
                lockLogin();
                lockCreate();
                clearAll();
                break;
            case ATTEMPTING:
            case CONNECTED:
                lockConnect();
                unlockLogin();
                break;
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        unlockConnect();
        lockAll();
        lockLogin();
        lockCreate();
        clearAll();
    }

    class ShutDownThread extends Thread {

        @Override
        public void run() {
            if (socket != null) {
                if (socket.debugFlagIsSet(Constants.instance().DEBUG_STATUS)) {
                    LOGGER.info("ShutdownHook: Shutting down Server Socket");
                }
                socket.shutdown();
            }
        }
    }

    class FxSocketListener implements SocketListener {

        @Override
        public void onMessage(String line) {
            try {
                if (line != null && !line.equals("")) {
                    if (line.startsWith("\\Login\\")) {
                        String[] result = line.split("\\\\");
                        if (result[2].equals("true")) {
                            textUser.setText(result[3]);
                            unlockAll();
                            lockLogin();
                            unlockCreate();
                            clearLogin();
                            Backstage.readFile();
                            Backstage.addToDisplay(listMovies);
                            displayInList();
                        }
                    }
                }
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Error");
                alert.setHeaderText("Error Reading Message");
                alert.setContentText(e.toString());
                alert.show();
            }
        }

        @Override
        public void onClosedStatus(boolean isClosed) {
            if (isClosed) {
                notifyDisconnected();
                displayState(ConnectionDisplayState.DISCONNECTED);
            } else {
                setIsConnected(true);
                displayState(ConnectionDisplayState.CONNECTED);
            }
        }
    }

    @FXML
    private void handleConnectButtonAction(ActionEvent event) {
        displayState(ConnectionDisplayState.ATTEMPTING);
        connect();
    }

    @FXML
    private void handleLoginButtonAction(ActionEvent event) {
        if (!textUserID.getText().equals("") && !textPassword.getText().equals("")) {
            String credentials = "\\Login\\" + textUserID.getText() + "\\" + textPassword.getText();
            socket.sendMessage(credentials);
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Incomplete Submission");
            alert.setContentText("Please input username and password to login");
            alert.show();
        }
    }

    @FXML
    private void handleSwitchButtonAction(ActionEvent event) {
        clearAll();
        lockAll();
        lockCreate();
        unlockLogin();
        socket.sendMessage("\\Switch\\");
    }

    @FXML
    private void handleCreateButtonAction(ActionEvent event) {
        if (!textUserID.getText().equals("") && !textPassword.getText().equals("")) {
            String credentials = "\\Create\\" + textUserID.getText() + "\\" + textPassword.getText();
            socket.sendMessage(credentials);
            clearLogin();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Incomplete Submission");
            alert.setContentText("Please input username and password to create new user");
            alert.show();
        }
    }

    @FXML
    private void handleClearButtonAction(ActionEvent event) {
        clearLogin();
    }

    @FXML
    private void handleMoviesListClicked(MouseEvent event) {
        try {
            int index = moviesList.getSelectionModel().getSelectedIndex();

            textID.setText(Backstage.getID(index).toString());
            textTitleD.setText(Backstage.getTitle(index));
            textPriceD.setText(Backstage.getPrice(index).toString());
            textRatingD.setText(Backstage.getRating(index));
            textYearD.setText(Backstage.getYear(index).toString());
            textGenreD.setText(Backstage.getGenre(index));
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Selecting Movie");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    @FXML
    private void handleSortTitleButtonAction(ActionEvent event) {
        LinkedList<String> listTitle = Backstage.getTitleList();
        LinkedList<String> sortedList = new LinkedList<>();
        sortedList = mergeSortTitle(listTitle);
        Backstage.sortTitle(sortedList);
        Backstage.addToDisplay(listMovies);
        displayInList();
    }

    private LinkedList<String> mergeSortTitle(LinkedList<String> unsorted) {
        if (unsorted.size() <= 1) {
            return unsorted;
        }

        LinkedList<String> left = new LinkedList<>();
        LinkedList<String> right = new LinkedList<>();

        int mid = unsorted.size() / 2;
        for (int i = 0; i < mid; i++) {
            left.addLast(unsorted.get(i));
        }
        for (int i = mid; i < unsorted.size(); i++) {
            right.addLast(unsorted.get(i));
        }

        left = mergeSortTitle(left);
        right = mergeSortTitle(right);
        return mergeTitle(left, right);
    }

    private LinkedList<String> mergeTitle(LinkedList<String> left, LinkedList<String> right) {
        LinkedList<String> result = new LinkedList<>();

        while (left.size() > 0 || right.size() > 0) {
            if (left.size() > 0 && right.size() > 0) {
                if (left.getFirst().compareTo(right.getFirst()) <= 0) {
                    result.addLast(left.getFirst());
                    left.remove(left.getFirst());
                } else {
                    result.addLast(right.getFirst());
                    right.remove(right.getFirst());
                }
            } else if (left.size() > 0) {
                result.addLast(left.getFirst());
                left.remove(left.getFirst());
            } else if (right.size() > 0) {
                result.addLast(right.getFirst());
                right.remove(right.getFirst());
            }
        }
        return result;
    }

    @FXML
    private void handleSortIDButtonAction(ActionEvent event) {
        LinkedList<Integer> listID = Backstage.getIDList();
        LinkedList<Integer> sortedList = new LinkedList<>();
        sortedList = mergeSortID(listID);
        Backstage.sortID(sortedList);
        Backstage.addToDisplay(listMovies);
        displayInList();
    }

    private LinkedList<Integer> mergeSortID(LinkedList<Integer> unsorted) {
        if (unsorted.size() <= 1) {
            return unsorted;
        }
        LinkedList<Integer> left = new LinkedList<>();
        LinkedList<Integer> right = new LinkedList<>();

        int mid = unsorted.size() / 2;
        for (int i = 0; i < mid; i++) {
            left.addLast(unsorted.get(i));
        }
        for (int i = mid; i < unsorted.size(); i++) {
            right.addLast(unsorted.get(i));
        }

        left = mergeSortID(left);
        right = mergeSortID(right);
        return mergeID(left, right);
    }

    private LinkedList<Integer> mergeID(LinkedList<Integer> left, LinkedList<Integer> right) {
        LinkedList<Integer> result = new LinkedList<Integer>();

        while (left.size() > 0 || right.size() > 0) {
            if (left.size() > 0 && right.size() > 0) {
                if (left.getFirst() <= right.getFirst()) {
                    result.addLast(left.getFirst());
                    left.remove(left.getFirst());
                } else {
                    result.addLast(right.getFirst());
                    right.remove(right.getFirst());
                }
            } else if (left.size() > 0) {
                result.addLast(left.getFirst());
                left.remove(left.getFirst());
            } else if (right.size() > 0) {
                result.addLast(right.getFirst());
                right.remove(right.getFirst());
            }
        }
        return result;
    }

    @FXML
    private void handleAddButtonAction(ActionEvent event) {
        boolean finished = false;

        if (!textTitleA.getText().equals("") && !textPriceA.getText().equals("") && !textRatingA.getText().equals("")
                && !textYearA.getText().equals("") && !textGenreA.getText().equals("")) {

            while (finished == false) {
                double newPrice;
                int newYear;

                try {
                    newPrice = Double.parseDouble(textPriceA.getText());
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Error");
                    alert.setHeaderText("Incorrect Format");
                    alert.setContentText("Please input a valid price (E.g. 12.34)");
                    alert.show();
                    break;
                }

                try {
                    newYear = Integer.parseInt(textYearA.getText());
                    if (newYear > (Calendar.getInstance().get(Calendar.YEAR))) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Error");
                        alert.setHeaderText("Invalid Year");
                        alert.setContentText("Please input a valid year (E.g. 1987)");
                        alert.show();
                        break;
                    }
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Note");
                    alert.setHeaderText("Incorrect Format");
                    alert.setContentText("Please input a valid year (E.g. 1987)");
                    alert.show();
                    break;
                }

                String newTitle = textTitleA.getText();
                String newRating = textRatingA.getText();
                String newGenre = textGenreA.getText();

                Backstage.writeToFile(newTitle, newPrice, newRating, newYear, newGenre);
                clearAdd();

                Backstage.readFile();
                Backstage.addToDisplay(listMovies);
                displayInList();
                finished = true;
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Incomplete Submission");
            alert.setContentText("Please fill in all the fields.");
            alert.show();
        }
    }

    @FXML
    private void handleNextButtonAction(ActionEvent event) {
        int curNode = moviesList.getSelectionModel().getSelectedIndex();
        String curData = null;

        if (textTitleD.getText() != null && !(textTitleD.getText().equals(""))) {
            curData = textTitleD.getText() + ", " + textYearD.getText();

            if (curNode < listMovies.size() && curNode != (listMovies.size() - 1)) {
                int index = listMovies.indexOf(curData);
                index += 1;
                String nextData = listMovies.get(index);
                String[] values = nextData.split(",");
                String result = Backstage.find(values[0]);
                String[] result2 = result.split(",");

                textID.setText(result2[0]);
                textTitleD.setText(result2[1]);
                textPriceD.setText(result2[2]);
                textRatingD.setText(result2[3]);
                textYearD.setText(result2[4]);
                textGenreD.setText(result2[5]);

                moviesList.getSelectionModel().select(index);
            } else {
                String nextData = listMovies.getFirst();

                String[] values = nextData.split(",");
                String result = Backstage.find(values[0]);
                String[] result2 = result.split(",");

                textID.setText(result2[0]);
                textTitleD.setText(result2[1]);
                textPriceD.setText(result2[2]);
                textRatingD.setText(result2[3]);
                textYearD.setText(result2[4]);
                textGenreD.setText(result2[5]);

                moviesList.getSelectionModel().select(0);
            }
        } else {
            String nextData = listMovies.getFirst();

            String[] values = nextData.split(",");
            String result = Backstage.find(values[0]);
            String[] result2 = result.split(",");

            textID.setText(result2[0]);
            textTitleD.setText(result2[1]);
            textPriceD.setText(result2[2]);
            textRatingD.setText(result2[3]);
            textYearD.setText(result2[4]);
            textGenreD.setText(result2[5]);

            moviesList.getSelectionModel().select(0);
        }
        if (!searchList.getItems().isEmpty()) {
            searchList.getSelectionModel().select(0);
            searchList.getSelectionModel().clearSelection();
        }
    }

    @FXML
    private void handlePrevButtonAction(ActionEvent event) {
        int curNode = moviesList.getSelectionModel().getSelectedIndex();
        String curData = null;

        if (textTitleD.getText() != null && !(textTitleD.getText().equals(""))) {
            curData = textTitleD.getText() + ", " + textYearD.getText();

            if (curNode > 0) {
                int index = listMovies.indexOf(curData);
                index -= 1;
                String prevData = listMovies.get(index);
                String[] values = prevData.split(",");
                String result = Backstage.find(values[0]);
                String[] result2 = result.split(",");

                textID.setText(result2[0]);
                textTitleD.setText(result2[1]);
                textPriceD.setText(result2[2]);
                textRatingD.setText(result2[3]);
                textYearD.setText(result2[4]);
                textGenreD.setText(result2[5]);

                moviesList.getSelectionModel().select(index);

            } else {
                String prevData = listMovies.getLast();

                String[] values = prevData.split(",");
                String result = Backstage.find(values[0]);
                String[] result2 = result.split(",");

                textID.setText(result2[0]);
                textTitleD.setText(result2[1]);
                textPriceD.setText(result2[2]);
                textRatingD.setText(result2[3]);
                textYearD.setText(result2[4]);
                textGenreD.setText(result2[5]);

                moviesList.getSelectionModel().select(listMovies.size() - 1);
            }
        } else {
            String prevData = listMovies.getLast();

            String[] values = prevData.split(",");
            String result = Backstage.find(values[0]);
            String[] result2 = result.split(",");

            textID.setText(result2[0]);
            textTitleD.setText(result2[1]);
            textPriceD.setText(result2[2]);
            textRatingD.setText(result2[3]);
            textYearD.setText(result2[4]);
            textGenreD.setText(result2[5]);

            moviesList.getSelectionModel().select(listMovies.size() - 1);
        }
        if (!searchList.getItems().isEmpty()) {
            searchList.getSelectionModel().select(0);
            searchList.getSelectionModel().clearSelection();
        }
    }

    @FXML
    private void handleResetButtonAction(ActionEvent event) {
        clearDetails();
        moviesList.getSelectionModel().select(0);
        moviesList.getSelectionModel().clearSelection();
        if (!searchList.getItems().isEmpty()) {
            searchList.getSelectionModel().select(0);
            searchList.getSelectionModel().clearSelection();
        }
    }

    @FXML
    private void handleClearSearchButtonAction(ActionEvent event) {
        clearSearch();
    }

    @FXML
    private void handleSearchButtonAction(ActionEvent event) {
        if (comboFilters.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Incomplete Submission");
            alert.setContentText("Please select a filter to search");
            alert.show();
        } else {
            String filter = comboFilters.getSelectionModel().getSelectedItem().toString();
            if (textSearch.getText() != null && !(textSearch.getText().equals(""))) {
                String target = textSearch.getText();
                if (filter.equals("Movie ID")) {
                    int targetID;
                    try {
                        targetID = Integer.parseInt(target);

                        LinkedList<Integer> tempList = Backstage.getIDList();
                        LinkedList<Integer> sortedList = new LinkedList<>();
                        sortedList = mergeSortID(tempList);
                        Backstage.sortID(sortedList);

                        int indexFound = Backstage.binarySearchID(sortedList, targetID);

                        if (indexFound == -1) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Note");
                            alert.setHeaderText("Unexisting ID");
                            alert.setContentText("ID " + targetID + " was not found");
                            alert.show();
                        } else {
                            String id = (Backstage.getID(indexFound)).toString();
                            String title = Backstage.getTitle(indexFound);
                            String price = (Backstage.getPrice(indexFound)).toString();
                            String rating = Backstage.getRating(indexFound);
                            String year = (Backstage.getYear(indexFound)).toString();
                            String genre = Backstage.getGenre(indexFound);

                            String found = id + "," + title + "," + price + "," + rating + "," + year + "," + genre;
                            searchList.getItems().clear();
                            searchList.getItems().add(found);
                        }

                    } catch (Exception e) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Error");
                        alert.setHeaderText("Invalid Submission");
                        alert.setContentText("Please input a valid Movie ID. E.g. 1982");
                        alert.show();
                    }

                } else if (filter.equals("Title")) {
                    LinkedList<String> listTitle = Backstage.getTitleList();
                    LinkedList<String> sortedList = new LinkedList<>();
                    sortedList = mergeSortTitle(listTitle);
                    Backstage.sortTitle(sortedList);

                    int indexFound = Backstage.binarySearchTitle(sortedList, target);

                    if (indexFound == -1) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Note");
                        alert.setHeaderText("Unexisting Title");
                        alert.setContentText("Title " + target + " was not found");
                        alert.show();
                    } else {
                        String id = (Backstage.getID(indexFound)).toString();
                        String title = Backstage.getTitle(indexFound);
                        String price = (Backstage.getPrice(indexFound)).toString();
                        String rating = Backstage.getRating(indexFound);
                        String year = (Backstage.getYear(indexFound)).toString();
                        String genre = Backstage.getGenre(indexFound);

                        String found = id + "," + title + "," + price + "," + rating + "," + year + "," + genre;
                        searchList.getItems().clear();
                        searchList.getItems().add(found);
                    }
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Error");
                alert.setHeaderText("Incomplete Submission");
                alert.setContentText("Please input " + filter + " to search");
                alert.show();
            }
        }
    }

    @FXML
    private void handleSearchListClicked(MouseEvent event) {
        try {
            if (moviesList.getItems().isEmpty()) {
            } else {
                moviesList.getSelectionModel().select(0);
                moviesList.getSelectionModel().clearSelection();
            }

            String selectedItem = searchList.getSelectionModel().getSelectedItem().toString();
            String[] values = selectedItem.split(",");

            textID.setText(values[0]);
            textTitleD.setText(values[1]);
            textPriceD.setText(values[2]);
            textRatingD.setText(values[3]);
            textYearD.setText(values[4]);
            textGenreD.setText(values[5]);
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("Error Selecting Movie");
            alert.setContentText(e.toString());
            alert.show();
        }
    }

    private void displayInList() {
        moviesList.getItems().clear();
        for (int i = 0; i < listMovies.size(); i++) {
            moviesList.getItems().add(listMovies.get(i));
        }
    }

    private void clearLogin() {
        textUserID.clear();
        textPassword.clear();
    }

    private void clearDetails() {
        textID.clear();
        textTitleD.clear();
        textPriceD.clear();
        textRatingD.clear();
        textYearD.clear();
        textGenreD.clear();
    }

    private void clearAdd() {
        textTitleA.clear();
        textPriceA.clear();
        textRatingA.clear();
        textYearA.clear();
        textGenreA.clear();
    }

    private void clearSearch() {
        textSearch.clear();
        searchList.getItems().clear();
        comboFilters.getSelectionModel().clearSelection();
    }

    private void clearAll() {
        clearLogin();
        clearDetails();
        clearAdd();
        clearSearch();
        textUser.clear();
        moviesList.getItems().clear();
    }

    private void lockLogin() {
        labelLogin.setDisable(true);
        labelUserID.setDisable(true);
        labelPassword.setDisable(true);
        textUserID.setDisable(true);
        textPassword.setDisable(true);
        buttonClear.setDisable(true);
        buttonLogin.setDisable(true);
    }

    private void unlockLogin() {
        labelLogin.setDisable(false);
        labelUserID.setDisable(false);
        labelPassword.setDisable(false);
        textUserID.setDisable(false);
        textPassword.setDisable(false);
        buttonClear.setDisable(false);
        buttonLogin.setDisable(false);
    }

    private void lockCreate() {
        labelLogin.setDisable(true);
        labelUserID.setDisable(true);
        labelPassword.setDisable(true);
        textUserID.setDisable(true);
        textPassword.setDisable(true);
        buttonClear.setDisable(true);
        buttonCreate.setDisable(true);
    }

    private void unlockCreate() {
        labelLogin.setDisable(false);
        labelUserID.setDisable(false);
        labelPassword.setDisable(false);
        textUserID.setDisable(false);
        textPassword.setDisable(false);
        buttonClear.setDisable(false);
        buttonCreate.setDisable(false);
    }

    private void lockAll() {
        labelUser.setDisable(true);
        textUser.setDisable(true);
        buttonSwitch.setDisable(true);

        labelMovies.setDisable(true);
        moviesList.setDisable(true);

        labelSearch.setDisable(true);
        labelFilter.setDisable(true);
        comboFilters.setDisable(true);
        textSearch.setDisable(true);
        buttonSearch.setDisable(true);
        searchList.setDisable(true);
        buttonClearSearch.setDisable(true);

        labelDetails.setDisable(true);
        labelID.setDisable(true);
        labelTitleD.setDisable(true);
        labelPriceD.setDisable(true);
        labelRatingD.setDisable(true);
        labelYearD.setDisable(true);
        labelGenreD.setDisable(true);
        textID.setDisable(true);
        textTitleD.setDisable(true);
        textPriceD.setDisable(true);
        textRatingD.setDisable(true);
        textYearD.setDisable(true);
        textGenreD.setDisable(true);
        buttonNext.setDisable(true);
        buttonReset.setDisable(true);
        buttonPrev.setDisable(true);

        labelAdd.setDisable(true);
        labelTitleA.setDisable(true);
        labelPriceA.setDisable(true);
        labelRatingA.setDisable(true);
        labelYearA.setDisable(true);
        labelGenreA.setDisable(true);
        textTitleA.setDisable(true);
        textPriceA.setDisable(true);
        textRatingA.setDisable(true);
        textYearA.setDisable(true);
        textGenreA.setDisable(true);
        buttonAdd.setDisable(true);

        buttonSortTitle.setDisable(true);
        buttonSortID.setDisable(true);
    }

    private void unlockAll() {
        labelUser.setDisable(false);
        textUser.setDisable(false);
        buttonSwitch.setDisable(false);

        labelMovies.setDisable(false);
        moviesList.setDisable(false);

        labelSearch.setDisable(false);
        labelFilter.setDisable(false);
        comboFilters.setDisable(false);
        comboFilters.setItems(FILTERS);
        textSearch.setDisable(false);
        buttonSearch.setDisable(false);
        searchList.setDisable(false);
        buttonClearSearch.setDisable(false);

        labelDetails.setDisable(false);
        labelID.setDisable(false);
        labelTitleD.setDisable(false);
        labelPriceD.setDisable(false);
        labelRatingD.setDisable(false);
        labelYearD.setDisable(false);
        labelGenreD.setDisable(false);
        textID.setDisable(false);
        textTitleD.setDisable(false);
        textPriceD.setDisable(false);
        textRatingD.setDisable(false);
        textYearD.setDisable(false);
        textGenreD.setDisable(false);
        buttonNext.setDisable(false);
        buttonPrev.setDisable(false);
        buttonReset.setDisable(false);

        labelAdd.setDisable(false);
        labelTitleA.setDisable(false);
        labelPriceA.setDisable(false);
        labelRatingA.setDisable(false);
        labelYearA.setDisable(false);
        labelGenreA.setDisable(false);
        textTitleA.setDisable(false);
        textPriceA.setDisable(false);
        textRatingA.setDisable(false);
        textYearA.setDisable(false);
        textGenreA.setDisable(false);
        buttonAdd.setDisable(false);

        buttonSortTitle.setDisable(false);
        buttonSortID.setDisable(false);
    }

    private void lockConnect() {
        labelPort.setDisable(false);
        textPort.setEditable(false);
        buttonConnect.setDisable(true);
    }

    private void unlockConnect() {
        labelPort.setDisable(false);
        textPort.setEditable(true);
        buttonConnect.setDisable(false);
    }
}
