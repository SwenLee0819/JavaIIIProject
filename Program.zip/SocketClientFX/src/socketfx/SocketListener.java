/*
 * Name:       Ke Swen Lee
 * Date:       26/11/2020
 * Student ID: 30010827
 * Reference:  https://blogs.oracle.com/jtc/update-to-javafx,-sockets-and-threading:-lessons-learned
 */
package socketfx;

public interface SocketListener {

    public void onMessage(String line);

    public void onClosedStatus(boolean isClosed);
}
