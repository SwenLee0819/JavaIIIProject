/*
 * Name:       Ke Swen Lee
 * Date:       26/11/2020
 * Student ID: 30010827
 * Reference:  https://blogs.oracle.com/jtc/update-to-javafx,-sockets-and-threading:-lessons-learned
 */
package socketfx;

import java.io.*;
import java.lang.invoke.MethodHandles;
import java.net.*;
import java.util.logging.Logger;

public abstract class GenericSocket implements SocketListener {

    private final static Logger LOGGER
            = Logger.getLogger(MethodHandles.lookup().lookupClass().getName());
    public int port;
    protected Socket socketConnection = null;
    private BufferedWriter output = null;
    private BufferedReader input = null;
    private boolean ready = false;
    private Thread socketReaderThread;
    private Thread setupThread;
    private int debugFlags;

    // Returns true if the specified debug flag is set.
    public boolean debugFlagIsSet(int flag) {
        return ((flag & debugFlags) != 0);
    }

    // Turn on debugging option.
    public void setDebugFlags(int flags) {
        debugFlags = flags;
    }

    // Get current set of debug flags.
    public int getDebugFlags() {
        return debugFlags;
    }

    // Turn off debugging option.
    public void clearDebugFlags() {
        debugFlags = Constants.instance().DEBUG_NONE;
    }

    // Set up connection in the background.
    public void connect() {
        try {
            setupThread = new SetupThread();
            setupThread.start();
            socketReaderThread = new SocketReaderThread();
            socketReaderThread.start();
        } catch (Exception e) {
            if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                LOGGER.info(e.getMessage());
            }
        }
    }

    /* Shutdown and close GenericSocket instance. Once the socket is closed, 
     * it cannot be reconnected, a new socket needs to be created
     */
    public void shutdown() {
        close();
    }

    /* Close GenericSocket instance. Once the socket is closed, 
     * it cannot be reconnected, a new socket needs to be created
     */
    private void close() {
        try {
            if (socketConnection != null && !socketConnection.isClosed()) {
                socketConnection.close();
            }
            closeAdditionalSockets();
            if (debugFlagIsSet(Constants.instance().DEBUG_STATUS)) {
                LOGGER.info("Connection closed");
            }
            onClosedStatus(true);
        } catch (IOException e) {
            if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                LOGGER.info(e.getMessage());
            }
        }
    }

    protected abstract void initSocketConnection() throws SocketException;

    protected abstract void closeAdditionalSockets();

    /*
     * Synchronized method waits until the SetupThread is
     * sufficiently initialized
     */
    private synchronized void waitForReady() {
        while (!ready) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
    }

    /*
     * Synchronized method that notifies waitForReady()
     * method that it can stop waiting.
     */
    private synchronized void notifyReady() {
        ready = true;
        notifyAll();
    }

    // Send a message in the form of a String to the socket
    public void sendMessage(String msg) {
        try {
            output.write(msg, 0, msg.length());
            output.newLine();
            output.flush();
            if (debugFlagIsSet(Constants.instance().DEBUG_SEND)) {
                String logMsg = "send> " + msg;
                LOGGER.info(logMsg);
            }
        } catch (IOException e) {
            if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                LOGGER.info(e.getMessage());
            }
        }
    }

    class SetupThread extends Thread {

        @Override
        public void run() {
            try {
                initSocketConnection();
                if (socketConnection != null && !socketConnection.isClosed()) {
                    input = new BufferedReader(new InputStreamReader(
                            socketConnection.getInputStream()));
                    output = new BufferedWriter(new OutputStreamWriter(
                            socketConnection.getOutputStream()));
                    output.flush();
                }
                // Notify SocketReaderThread that it can now start.
                notifyReady();
            } catch (IOException e) {
                if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                    LOGGER.info(e.getMessage());
                }
                // Notify SocketReaderThread to exit.
                notifyReady();
            }
        }
    }

    class SocketReaderThread extends Thread {

        @Override
        public void run() {
            // Wait until the socket is set up before beginning to read.
            waitForReady();
            if (socketConnection != null && socketConnection.isConnected()) {
                onClosedStatus(false);
            }
            try {
                if (input != null) {
                    String line;
                    while ((line = input.readLine()) != null) {
                        if (debugFlagIsSet(Constants.instance().DEBUG_RECV)) {
                            String logMsg = "recv> " + line;
                            LOGGER.info(logMsg);
                        }
                        onMessage(line);
                    }
                }
            } catch (IOException e) {
                if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                    LOGGER.info(e.getMessage());
                }
            } finally {
                close();
            }
        }
    }

    public GenericSocket() {
        this(Constants.instance().DEFAULT_PORT,
                Constants.instance().DEBUG_NONE);
    }

    public GenericSocket(int port) {
        this(port, Constants.instance().DEBUG_NONE);
    }

    public GenericSocket(int port, int debugFlags) {
        this.port = port;
        this.debugFlags = debugFlags;
    }
}
