/*
 * Name:       Ke Swen Lee
 * Date:       26/11/2020
 * Student ID: 30010827
 * Reference:  https://blogs.oracle.com/jtc/update-to-javafx,-sockets-and-threading:-lessons-learned
 */
package socketfx;

import java.io.IOException;
import java.net.*;

public class FxSocketClient extends GenericSocket
        implements SocketListener {

    public String host;
    private SocketListener fxListener;

    // Called when a message is received from the socket, read line.
    @Override
    public void onMessage(final String line) {
        javafx.application.Platform.runLater(new Runnable() {
            @Override
            public void run() {
                fxListener.onMessage(line);
            }
        });
    }

    // Called when the socket opens or closes
    @Override
    public void onClosedStatus(final boolean isClosed) {
        javafx.application.Platform.runLater(new Runnable() {
            @Override
            public void run() {
                fxListener.onClosedStatus(isClosed);
            }
        });
    }

    // Initialise server socket and issuing accept()
    @Override
    protected void initSocketConnection() throws SocketException {
        try {
            socketConnection = new Socket();
            // Allows the socket to be bound even though a previous connection is in a timeout state.
            socketConnection.setReuseAddress(true);
            // Create a socket connection to the server
            socketConnection.connect(new InetSocketAddress(host, port));
            if (debugFlagIsSet(Constants.instance().DEBUG_STATUS)) {
                System.out.println("Connected to " + host
                        + "at port " + port);
            }
        } catch (IOException e) {
            if (debugFlagIsSet(Constants.instance().DEBUG_EXCEPTIONS)) {
                e.printStackTrace();
            }
            throw new SocketException();
        }
    }

    @Override
    protected void closeAdditionalSockets() {
    }

    public FxSocketClient(SocketListener fxListener,
            String host, int port, int debugFlags) {
        super(port, debugFlags);
        this.host = host;
        this.fxListener = fxListener;
    }

    public FxSocketClient(SocketListener fxListener) {
        this(fxListener, Constants.instance().DEFAULT_HOST,
                Constants.instance().DEFAULT_PORT,
                Constants.instance().DEBUG_NONE);
    }

    public FxSocketClient(SocketListener fxListener,
            String host, int port) {
        this(fxListener, host, port, Constants.instance().DEBUG_NONE);
    }
}
